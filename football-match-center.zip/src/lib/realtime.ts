// Internal helper: notify the socket.io mini-service of a match change
// so it can push the update live to all connected browsers.
//
// The socket.io server itself listens on port 3003 (for browser WebSocket
// traffic via the Caddy gateway). The internal control HTTP endpoint lives
// on port 3004 (localhost only) so that Next.js API routes can trigger
// broadcasts without going through the browser gateway.

const CONTROL_PORT = process.env.REALTIME_CONTROL_PORT || '3004'
const CONTROL_HOST = process.env.REALTIME_HOST || '127.0.0.1'

export async function broadcastMatchEvent(event: {
  type: 'created' | 'updated' | 'deleted'
  match?: any
  matchId?: string
}) {
  try {
    await fetch(`http://${CONTROL_HOST}:${CONTROL_PORT}/internal/broadcast`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(event),
    })
  } catch (err) {
    // Non-fatal: clients will refresh via periodic polling fallback.
    console.error('[broadcastMatchEvent] failed:', err)
  }
}
