export type MatchStatus = 'upcoming' | 'live' | 'finished'

export interface Match {
  id: string
  teamA: string
  teamB: string
  kickoffAt: string // ISO
  durationMin: number
  playersPerSide: number
  goalsTarget: number
  scoreA: number
  scoreB: number
  status: MatchStatus
  venue: string
  notes: string
  createdAt: string
  updatedAt: string
}
