import { cookies } from 'next/headers'
import crypto from 'crypto'

// Admin credentials — configured by the site owner (Anish).
// These can be overridden via env vars at deploy time.
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'anish25433'
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'anish@25433'

// Session token signing secret. In production set ADMIN_SESSION_SECRET.
const SESSION_SECRET = process.env.ADMIN_SESSION_SECRET || 'anish-football-match-center-dev-secret-2026'
const SESSION_COOKIE = 'anish_admin_session'
const SESSION_MAX_AGE = 60 * 60 * 24 * 7 // 7 days

function sign(payload: string): string {
  const hmac = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex')
  return `${payload}.${hmac}`
}

function verify(token: string): boolean {
  const idx = token.lastIndexOf('.')
  if (idx === -1) return false
  const payload = token.slice(0, idx)
  const sig = token.slice(idx + 1)
  const expected = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex')
  try {
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))
  } catch {
    return false
  }
}

export function verifyCredentials(username: string, password: string): boolean {
  return username === ADMIN_USERNAME && password === ADMIN_PASSWORD
}

export async function createSession() {
  const expiresAt = Date.now() + SESSION_MAX_AGE * 1000
  const payload = `admin:${expiresAt}`
  const token = sign(payload)
  const store = await cookies()
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_MAX_AGE,
    secure: process.env.NODE_ENV === 'production',
  })
}

export async function destroySession() {
  const store = await cookies()
  store.delete(SESSION_COOKIE)
}

export async function isAuthenticated(): Promise<boolean> {
  try {
    const store = await cookies()
    const token = store.get(SESSION_COOKIE)?.value
    if (!token) return false
    if (!verify(token)) return false
    const idx = token.lastIndexOf('.')
    const payload = token.slice(0, idx)
    const parts = payload.split(':')
    const expiresAt = Number(parts[1])
    if (!expiresAt || Date.now() > expiresAt) return false
    return true
  } catch {
    return false
  }
}
