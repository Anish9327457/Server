'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import { io, Socket } from 'socket.io-client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { useToast } from '@/hooks/use-toast'
import { Toaster } from '@/components/ui/toaster'
import {
  GoalIcon,
  InstagramIcon,
  MessageCircleIcon,
  LockIcon,
  LogOutIcon,
  PlusIcon,
  PencilIcon,
  TrashIcon,
  ClockIcon,
  UsersIcon,
  MapPinIcon,
  TrophyIcon,
  TimerIcon,
  ShieldIcon,
} from 'lucide-react'
import type { Match, MatchStatus } from '@/lib/types'

// ============================================================
// Footer (always shown at the bottom of the page)
// ============================================================
function Footer() {
  const INSTAGRAM = 'https://instagram.com/anish25433'
  const WHATSAPP_NUMBER = '918240197583' // 8240197583 with India country code 91
  const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
    "Hi Anish, I just visited your Football Match Center website."
  )}`

  return (
    <footer className="mt-auto border-t border-emerald-900/40 bg-gradient-to-b from-emerald-950/80 to-black">
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-col items-center gap-5 text-center">
          <div className="flex items-center gap-2 text-lg font-bold text-emerald-300">
            <GoalIcon className="h-6 w-6" />
            <span>Football Match Center</span>
          </div>
          <p className="text-sm text-emerald-100/70">
            This website is made by <span className="font-semibold text-white">Anish Biswas.</span>
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href={INSTAGRAM}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-pink-500 via-fuchsia-500 to-amber-400 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-fuchsia-900/30 transition hover:scale-[1.03] hover:shadow-fuchsia-700/40"
            >
              <InstagramIcon className="h-4 w-4" />
              <span>Instagram @anish25433</span>
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-green-900/30 transition hover:scale-[1.03] hover:bg-[#1ebe5d]"
            >
              <MessageCircleIcon className="h-4 w-4" />
              <span>WhatsApp 8240197583</span>
            </a>
          </div>
          <p className="text-xs text-emerald-100/40">
            &copy; {new Date().getFullYear()} Anish Biswas. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}

// ============================================================
// Admin login dialog
// ============================================================
function AdminLoginDialog({ onLoggedIn }: { onLoggedIn: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const { toast } = useToast()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast({
          title: 'Login failed',
          description: data?.error || 'Invalid credentials',
          variant: 'destructive',
        })
        return
      }
      toast({ title: 'Welcome back, Admin', description: 'You can now manage matches.' })
      setOpen(false)
      setUsername('')
      setPassword('')
      onLoggedIn()
    } catch (err: any) {
      toast({
        title: 'Login failed',
        description: err?.message || 'Network error',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="border-emerald-500/40 text-emerald-100 hover:bg-emerald-900/30">
          <LockIcon className="mr-2 h-4 w-4" /> Admin Login
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-white text-gray-900">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LockIcon className="h-5 w-5 text-emerald-600" /> Admin Login
          </DialogTitle>
          <DialogDescription>
            Only the admin can upload and manage match details.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="login-username">Username</Label>
            <Input
              id="login-username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="login-password">Password</Label>
            <Input
              id="login-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading} className="bg-emerald-600 hover:bg-emerald-700">
              {loading ? 'Logging in…' : 'Log in'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// ============================================================
// Status badge
// ============================================================
function StatusBadge({ status }: { status: MatchStatus }) {
  if (status === 'live') {
    return (
      <Badge className="bg-red-600 text-white hover:bg-red-600 animate-pulse">
        <span className="mr-1 inline-block h-2 w-2 rounded-full bg-white" /> LIVE
      </Badge>
    )
  }
  if (status === 'finished') {
    return <Badge variant="secondary" className="bg-gray-600 text-white hover:bg-gray-600">Full Time</Badge>
  }
  return <Badge className="bg-emerald-600 text-white hover:bg-emerald-600">Upcoming</Badge>
}

// ============================================================
// Single match card
// ============================================================
function MatchCard({
  match,
  isAdmin,
  onEdit,
  onDelete,
}: {
  match: Match
  isAdmin: boolean
  onEdit: (m: Match) => void
  onDelete: (m: Match) => void
}) {
  const kickoff = new Date(match.kickoffAt)
  const dateStr = kickoff.toLocaleDateString(undefined, {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
  const timeStr = kickoff.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  })

  return (
    <Card className="overflow-hidden border-emerald-900/30 bg-white/95 shadow-lg shadow-emerald-950/30">
      <div className="flex items-center justify-between bg-gradient-to-r from-emerald-700 to-emerald-800 px-4 py-2 text-white">
        <StatusBadge status={match.status} />
        <div className="flex items-center gap-1 text-xs text-emerald-100">
          <ClockIcon className="h-3.5 w-3.5" />
          <span>{dateStr} • {timeStr}</span>
        </div>
      </div>
      <CardContent className="p-5">
        {/* Teams + score */}
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="text-right">
            <div className="text-xs uppercase tracking-wide text-emerald-700">Team A</div>
            <div className="truncate text-lg font-bold text-gray-900">{match.teamA}</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-3xl font-extrabold tabular-nums text-emerald-900">
              {match.scoreA}
              <span className="mx-1 text-gray-400">:</span>
              {match.scoreB}
            </div>
            <div className="text-[10px] uppercase tracking-widest text-gray-500">score</div>
          </div>
          <div className="text-left">
            <div className="text-xs uppercase tracking-wide text-emerald-700">Team B</div>
            <div className="truncate text-lg font-bold text-gray-900">{match.teamB}</div>
          </div>
        </div>

        <Separator className="my-4 bg-emerald-900/10" />

        {/* Match details grid */}
        <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div className="flex items-center gap-2">
            <TimerIcon className="h-4 w-4 text-emerald-600" />
            <div>
              <div className="text-[10px] uppercase tracking-wide text-gray-500">Duration</div>
              <div className="font-semibold text-gray-900">{match.durationMin} min</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <UsersIcon className="h-4 w-4 text-emerald-600" />
            <div>
              <div className="text-[10px] uppercase tracking-wide text-gray-500">Per Side</div>
              <div className="font-semibold text-gray-900">{match.playersPerSide} players</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <TrophyIcon className="h-4 w-4 text-emerald-600" />
            <div>
              <div className="text-[10px] uppercase tracking-wide text-gray-500">Target Goals</div>
              <div className="font-semibold text-gray-900">
                {match.goalsTarget > 0 ? `${match.goalsTarget} goals` : 'No limit'}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <MapPinIcon className="h-4 w-4 text-emerald-600" />
            <div>
              <div className="text-[10px] uppercase tracking-wide text-gray-500">Venue</div>
              <div className="font-semibold text-gray-900 truncate">
                {match.venue || 'TBD'}
              </div>
            </div>
          </div>
        </div>

        {match.notes && (
          <div className="mt-3 rounded-md bg-emerald-50 px-3 py-2 text-xs text-emerald-900">
            <span className="font-semibold">Notes: </span>{match.notes}
          </div>
        )}
      </CardContent>

      {isAdmin && (
        <CardFooter className="flex justify-end gap-2 border-t border-emerald-900/10 bg-emerald-50/50 px-4 py-2">
          <Button size="sm" variant="outline" onClick={() => onEdit(match)}>
            <PencilIcon className="mr-1 h-3.5 w-3.5" /> Edit
          </Button>
          <Button size="sm" variant="destructive" onClick={() => onDelete(match)}>
            <TrashIcon className="mr-1 h-3.5 w-3.5" /> Delete
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

// ============================================================
// Match form (create / edit)
// ============================================================
function toLocalDatetimeInputValue(iso: string) {
  const d = new Date(iso)
  const off = d.getTimezoneOffset()
  const local = new Date(d.getTime() - off * 60 * 1000)
  return local.toISOString().slice(0, 16)
}

function MatchFormDialog({
  open,
  onOpenChange,
  initial,
  onSubmit,
  submitting,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  initial: Match | null
  onSubmit: (data: any) => void
  submitting: boolean
}) {
  // We force a remount of the inner form whenever the dialog opens or the
  // target match changes, so the form's useState initializers run with the
  // correct values (avoids setState-in-effect lint errors).
  const formKey = `${open ? 'open' : 'closed'}:${initial?.id ?? 'new'}`

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto bg-white text-gray-900 sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GoalIcon className="h-5 w-5 text-emerald-600" />
            {initial ? 'Edit match' : 'Add a new match'}
          </DialogTitle>
          <DialogDescription>
            {initial
              ? 'Update the match details below. Changes go live instantly.'
              : 'Fill in the match details below. They will go live as soon as you save.'}
          </DialogDescription>
        </DialogHeader>
        <MatchForm
          key={formKey}
          initial={initial}
          onSubmit={onSubmit}
          onCancel={() => onOpenChange(false)}
          submitting={submitting}
        />
      </DialogContent>
    </Dialog>
  )
}

function MatchForm({
  initial,
  onSubmit,
  onCancel,
  submitting,
}: {
  initial: Match | null
  onSubmit: (data: any) => void
  onCancel: () => void
  submitting: boolean
}) {
  const isEdit = !!initial
  const [teamA, setTeamA] = useState(initial?.teamA ?? '')
  const [teamB, setTeamB] = useState(initial?.teamB ?? '')
  const [kickoffAt, setKickoffAt] = useState(
    initial ? toLocalDatetimeInputValue(initial.kickoffAt) : ''
  )
  const [durationMin, setDurationMin] = useState(String(initial?.durationMin ?? 90))
  const [playersPerSide, setPlayersPerSide] = useState(String(initial?.playersPerSide ?? 11))
  const [goalsTarget, setGoalsTarget] = useState(String(initial?.goalsTarget ?? 0))
  const [scoreA, setScoreA] = useState(String(initial?.scoreA ?? 0))
  const [scoreB, setScoreB] = useState(String(initial?.scoreB ?? 0))
  const [status, setStatus] = useState<MatchStatus>(initial?.status ?? 'upcoming')
  const [venue, setVenue] = useState(initial?.venue ?? '')
  const [notes, setNotes] = useState(initial?.notes ?? '')

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      teamA,
      teamB,
      kickoffAt: kickoffAt ? new Date(kickoffAt).toISOString() : undefined,
      durationMin: Number(durationMin),
      playersPerSide: Number(playersPerSide),
      goalsTarget: Number(goalsTarget),
      scoreA: Number(scoreA),
      scoreB: Number(scoreB),
      status,
      venue,
      notes,
    })
  }

  return (
    <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="teamA">Team A</Label>
              <Input id="teamA" value={teamA} onChange={(e) => setTeamA(e.target.value)} required placeholder="e.g. Real Reds" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="teamB">Team B</Label>
              <Input id="teamB" value={teamB} onChange={(e) => setTeamB(e.target.value)} required placeholder="e.g. Blue Strikers" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="kickoff">Kickoff date &amp; time</Label>
            <Input id="kickoff" type="datetime-local" value={kickoffAt} onChange={(e) => setKickoffAt(e.target.value)} required />
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="space-y-1.5">
              <Label htmlFor="durationMin">Duration (min)</Label>
              <Input id="durationMin" type="number" min={1} value={durationMin} onChange={(e) => setDurationMin(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="playersPerSide">Players / side</Label>
              <Input id="playersPerSide" type="number" min={1} value={playersPerSide} onChange={(e) => setPlayersPerSide(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="goalsTarget">Target goals</Label>
              <Input id="goalsTarget" type="number" min={0} value={goalsTarget} onChange={(e) => setGoalsTarget(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="status">Status</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as MatchStatus)}>
                <SelectTrigger id="status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="finished">Finished</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="scoreA">{teamA || 'Team A'} score</Label>
              <Input id="scoreA" type="number" min={0} value={scoreA} onChange={(e) => setScoreA(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="scoreB">{teamB || 'Team B'} score</Label>
              <Input id="scoreB" type="number" min={0} value={scoreB} onChange={(e) => setScoreB(e.target.value)} required />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="venue">Venue (optional)</Label>
            <Input id="venue" value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="e.g. Community Ground" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="e.g. Bring dark + light jerseys" />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
            <Button type="submit" disabled={submitting} className="bg-emerald-600 hover:bg-emerald-700">
              {submitting ? 'Saving…' : isEdit ? 'Save changes' : 'Add match'}
            </Button>
          </DialogFooter>
    </form>
  )
}

// ============================================================
// Delete confirmation dialog
// ============================================================
function DeleteDialog({
  open,
  onOpenChange,
  match,
  onConfirm,
  submitting,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  match: Match | null
  onConfirm: () => void
  submitting: boolean
}) {
  if (!match) return null
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white text-gray-900 sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-700">
            <TrashIcon className="h-5 w-5" /> Delete match?
          </DialogTitle>
          <DialogDescription>
            This will permanently remove the match
            {' '}<span className="font-semibold text-gray-900">{match.teamA} vs {match.teamB}</span>
            {' '}from the live board. This cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button variant="destructive" onClick={onConfirm} disabled={submitting}>
            {submitting ? 'Deleting…' : 'Delete match'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

// ============================================================
// Main page
// ============================================================
export default function Home() {
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [formOpen, setFormOpen] = useState(false)
  const [editingMatch, setEditingMatch] = useState<Match | null>(null)
  const [deletingMatch, setDeletingMatch] = useState<Match | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [liveConnected, setLiveConnected] = useState(false)
  const socketRef = useRef<Socket | null>(null)
  const { toast } = useToast()

  // Fetch matches from the API
  const refreshMatches = useCallback(async () => {
    try {
      const res = await fetch('/api/matches', { cache: 'no-store' })
      const data = await res.json()
      if (Array.isArray(data?.matches)) {
        setMatches(data.matches)
      }
    } catch (err) {
      // silent — toast spam would be annoying
    } finally {
      setLoading(false)
    }
  }, [])

  // Check admin session
  const refreshSession = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/session', { cache: 'no-store' })
      const data = await res.json()
      setIsAdmin(!!data?.authenticated)
    } catch {
      setIsAdmin(false)
    }
  }, [])

  // Initial load
  useEffect(() => {
    refreshMatches()
    refreshSession()
  }, [refreshMatches, refreshSession])

  // Socket.io: live updates
  useEffect(() => {
    const socket = io('/?XTransformPort=3003', {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      timeout: 10000,
    })
    socketRef.current = socket

    socket.on('connect', () => setLiveConnected(true))
    socket.on('disconnect', () => setLiveConnected(false))
    socket.on('connect_error', () => setLiveConnected(false))

    socket.on('match:event', (event: { type: 'created' | 'updated' | 'deleted'; match?: Match; matchId?: string }) => {
      if (event.type === 'created' && event.match) {
        setMatches((prev) => {
          if (prev.find((m) => m.id === event.match!.id)) return prev
          return [...prev, event.match!]
        })
      } else if (event.type === 'updated' && event.match) {
        setMatches((prev) => prev.map((m) => (m.id === event.match!.id ? event.match! : m)))
      } else if (event.type === 'deleted' && event.matchId) {
        setMatches((prev) => prev.filter((m) => m.id !== event.matchId))
      }
    })

    return () => {
      socket.disconnect()
      socketRef.current = null
    }
  }, [])

  // Periodic refresh as a safety net
  useEffect(() => {
    const id = setInterval(() => {
      refreshMatches()
    }, 20000)
    return () => clearInterval(id)
  }, [refreshMatches])

  // Admin actions
  const handleCreate = () => {
    setEditingMatch(null)
    setFormOpen(true)
  }
  const handleEdit = (m: Match) => {
    setEditingMatch(m)
    setFormOpen(true)
  }
  const handleDeleteClick = (m: Match) => {
    setDeletingMatch(m)
  }

  const submitForm = async (data: any) => {
    setSubmitting(true)
    try {
      if (editingMatch) {
        const res = await fetch(`/api/matches/${editingMatch.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        })
        const json = await res.json()
        if (!res.ok) {
          toast({ title: 'Update failed', description: json?.error || 'Unknown error', variant: 'destructive' })
          return
        }
        toast({ title: 'Match updated', description: 'Live board refreshed.' })
        setMatches((prev) => prev.map((m) => (m.id === editingMatch.id ? json.match : m)))
      } else {
        const res = await fetch('/api/matches', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        })
        const json = await res.json()
        if (!res.ok) {
          toast({ title: 'Add failed', description: json?.error || 'Unknown error', variant: 'destructive' })
          return
        }
        toast({ title: 'Match added', description: `${json.match.teamA} vs ${json.match.teamB} is now live.` })
        // Socket.io will also push this — but add locally as a fallback
        setMatches((prev) => prev.find((m) => m.id === json.match.id) ? prev : [json.match, ...prev])
      }
      setFormOpen(false)
      setEditingMatch(null)
    } catch (err: any) {
      toast({ title: 'Error', description: err?.message || 'Network error', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  const confirmDelete = async () => {
    if (!deletingMatch) return
    setSubmitting(true)
    try {
      const res = await fetch(`/api/matches/${deletingMatch.id}`, { method: 'DELETE' })
      if (!res.ok) {
        const json = await res.json().catch(() => ({}))
        toast({ title: 'Delete failed', description: json?.error || 'Unknown error', variant: 'destructive' })
        return
      }
      toast({ title: 'Match deleted' })
      setMatches((prev) => prev.filter((m) => m.id !== deletingMatch.id))
      setDeletingMatch(null)
    } finally {
      setSubmitting(false)
    }
  }

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    setIsAdmin(false)
    toast({ title: 'Logged out' })
  }

  // Sort: live first, then upcoming (by time), then finished (by time desc)
  const sorted = [...matches].sort((a, b) => {
    const rank = (s: MatchStatus) => (s === 'live' ? 0 : s === 'upcoming' ? 1 : 2)
    const ra = rank(a.status), rb = rank(b.status)
    if (ra !== rb) return ra - rb
    if (a.status === 'finished') {
      return new Date(b.kickoffAt).getTime() - new Date(a.kickoffAt).getTime()
    }
    return new Date(a.kickoffAt).getTime() - new Date(b.kickoffAt).getTime()
  })

  const liveCount = matches.filter((m) => m.status === 'live').length
  const upcomingCount = matches.filter((m) => m.status === 'upcoming').length

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-emerald-950 via-black to-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-emerald-900/40 bg-emerald-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg">
              <GoalIcon className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="text-base font-bold leading-none sm:text-lg">Football Match Center</div>
              <div className="text-[10px] uppercase tracking-widest text-emerald-300/70">
                Live match organizer
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className={`hidden items-center gap-1.5 rounded-full px-3 py-1 text-xs sm:flex ${
              liveConnected ? 'bg-emerald-500/20 text-emerald-200' : 'bg-gray-700/40 text-gray-300'
            }`}>
              <span className={`inline-block h-2 w-2 rounded-full ${liveConnected ? 'bg-emerald-400 animate-pulse' : 'bg-gray-400'}`} />
              {liveConnected ? 'Live' : 'Connecting…'}
            </div>
            {isAdmin ? (
              <>
                <Button onClick={handleCreate} className="bg-emerald-600 hover:bg-emerald-700">
                  <PlusIcon className="mr-1 h-4 w-4" /> Add match
                </Button>
                <Button variant="outline" onClick={handleLogout} className="border-emerald-500/40 text-emerald-100 hover:bg-emerald-900/30">
                  <LogOutIcon className="mr-1 h-4 w-4" /> Logout
                </Button>
              </>
            ) : (
              <AdminLoginDialog onLoggedIn={refreshSession} />
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-emerald-900/40 bg-gradient-to-br from-emerald-800 via-emerald-900 to-black">
        <div
          className="pointer-events-none absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 20%, rgba(255,255,255,0.25) 0, transparent 40%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.18) 0, transparent 35%)',
          }}
        />
        <div className="relative mx-auto max-w-6xl px-4 py-10 text-center sm:py-14">
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl">
            Kickoff. Score. <span className="text-emerald-400">Celebrate.</span>
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-sm text-emerald-100/80 sm:text-base">
            See which team is playing whom, when the match kicks off, the live score, match duration and how many players per side — updated in real time as the admin uploads each fixture.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <div className="rounded-xl bg-red-600/20 px-5 py-2 text-red-200 ring-1 ring-red-500/40">
              <div className="text-2xl font-bold">{liveCount}</div>
              <div className="text-[10px] uppercase tracking-widest">Live now</div>
            </div>
            <div className="rounded-xl bg-emerald-500/20 px-5 py-2 text-emerald-200 ring-1 ring-emerald-500/40">
              <div className="text-2xl font-bold">{upcomingCount}</div>
              <div className="text-[10px] uppercase tracking-widest">Upcoming</div>
            </div>
            <div className="rounded-xl bg-white/10 px-5 py-2 text-white ring-1 ring-white/20">
              <div className="text-2xl font-bold">{matches.length}</div>
              <div className="text-[10px] uppercase tracking-widest">Total fixtures</div>
            </div>
          </div>
        </div>
      </section>

      {/* Matches list */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <ShieldIcon className="h-5 w-5 text-emerald-400" /> Match board
          </h2>
          <Button variant="ghost" size="sm" onClick={refreshMatches} className="text-emerald-200 hover:bg-emerald-900/30">
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-48 animate-pulse rounded-xl bg-white/5 ring-1 ring-white/10" />
            ))}
          </div>
        ) : sorted.length === 0 ? (
          <Card className="border-dashed border-emerald-700/40 bg-white/5 text-emerald-50">
            <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
              <GoalIcon className="h-10 w-10 text-emerald-500/70" />
              <div className="text-lg font-semibold">No matches scheduled yet</div>
              <p className="max-w-md text-sm text-emerald-100/70">
                When the admin uploads a fixture, it will appear here instantly and everyone viewing this page will see it live.
              </p>
              {isAdmin && (
                <Button onClick={handleCreate} className="mt-2 bg-emerald-600 hover:bg-emerald-700">
                  <PlusIcon className="mr-1 h-4 w-4" /> Add the first match
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {sorted.map((m) => (
              <MatchCard
                key={m.id}
                match={m}
                isAdmin={isAdmin}
                onEdit={handleEdit}
                onDelete={handleDeleteClick}
              />
            ))}
          </div>
        )}
      </main>

      {/* Dialogs */}
      <MatchFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        initial={editingMatch}
        onSubmit={submitForm}
        submitting={submitting}
      />
      <DeleteDialog
        open={!!deletingMatch}
        onOpenChange={(v) => { if (!v) setDeletingMatch(null) }}
        match={deletingMatch}
        onConfirm={confirmDelete}
        submitting={submitting}
      />

      <Footer />
    </div>
  )
}
