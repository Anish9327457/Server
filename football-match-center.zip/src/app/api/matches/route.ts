import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAuthenticated } from '@/lib/auth'
import { broadcastMatchEvent } from '@/lib/realtime'

function serialize(m: any) {
  return {
    id: m.id,
    teamA: m.teamA,
    teamB: m.teamB,
    kickoffAt: m.kickoffAt.toISOString(),
    durationMin: m.durationMin,
    playersPerSide: m.playersPerSide,
    goalsTarget: m.goalsTarget,
    scoreA: m.scoreA,
    scoreB: m.scoreB,
    status: m.status,
    venue: m.venue ?? '',
    notes: m.notes ?? '',
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }
}

// Public: list all upcoming + live + recent finished matches
export async function GET() {
  try {
    const matches = await db.match.findMany({
      orderBy: [{ status: 'asc' }, { kickoffAt: 'asc' }],
    })
    return NextResponse.json({ matches: matches.map(serialize) })
  } catch (err: any) {
    return NextResponse.json(
      {
        error: 'database_query_failed',
        message: err?.message ?? String(err),
        hasDatabaseUrl: !!process.env.DATABASE_URL,
      },
      { status: 500 }
    )
  }
}

// Admin only: create a match
export async function POST(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const teamA = String(body?.teamA ?? '').trim()
  const teamB = String(body?.teamB ?? '').trim()
  const kickoffAtRaw = String(body?.kickoffAt ?? '').trim()
  const durationMin = Number(body?.durationMin ?? 90)
  const playersPerSide = Number(body?.playersPerSide ?? 11)
  const goalsTarget = Number(body?.goalsTarget ?? 0)
  const scoreA = Number(body?.scoreA ?? 0)
  const scoreB = Number(body?.scoreB ?? 0)
  const status = String(body?.status ?? 'upcoming')
  const venue = String(body?.venue ?? '').trim() || null
  const notes = String(body?.notes ?? '').trim() || null

  if (!teamA || !teamB) {
    return NextResponse.json({ error: 'Both team names are required' }, { status: 400 })
  }
  if (teamA.toLowerCase() === teamB.toLowerCase()) {
    return NextResponse.json({ error: 'Team A and Team B must be different' }, { status: 400 })
  }
  if (!kickoffAtRaw || isNaN(Date.parse(kickoffAtRaw))) {
    return NextResponse.json({ error: 'A valid kickoff date/time is required' }, { status: 400 })
  }
  const kickoffAt = new Date(kickoffAtRaw)
  if (!['upcoming', 'live', 'finished'].includes(status)) {
    return NextResponse.json({ error: 'Invalid status' }, { status: 400 })
  }

  const match = await db.match.create({
    data: {
      teamA,
      teamB,
      kickoffAt,
      durationMin: Number.isFinite(durationMin) ? durationMin : 90,
      playersPerSide: Number.isFinite(playersPerSide) ? playersPerSide : 11,
      goalsTarget: Number.isFinite(goalsTarget) ? goalsTarget : 0,
      scoreA: Number.isFinite(scoreA) ? scoreA : 0,
      scoreB: Number.isFinite(scoreB) ? scoreB : 0,
      status,
      venue,
      notes,
    },
  })

  await broadcastMatchEvent({ type: 'created', match: serialize(match) })
  return NextResponse.json({ match: serialize(match) })
}
