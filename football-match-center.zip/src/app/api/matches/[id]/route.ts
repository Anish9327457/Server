import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAuthenticated } from '@/lib/auth'
import { broadcastMatchEvent } from '@/lib/realtime'

function serialize(m: any) {
  return {
    id: m.id,
    teamA: m.teamA,
    teamB: m.teamB,
    kickoffAt: m.kickoffAt.toISOString(),
    durationMin: m.durationMin,
    playersPerSide: m.playersPerSide,
    goalsTarget: m.goalsTarget,
    scoreA: m.scoreA,
    scoreB: m.scoreB,
    status: m.status,
    venue: m.venue ?? '',
    notes: m.notes ?? '',
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const { id } = await params
  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const existing = await db.match.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json({ error: 'Match not found' }, { status: 404 })
  }

  const data: any = {}
  if (typeof body?.teamA === 'string') data.teamA = body.teamA.trim()
  if (typeof body?.teamB === 'string') data.teamB = body.teamB.trim()
  if (data.teamA && data.teamB && data.teamA.toLowerCase() === data.teamB.toLowerCase()) {
    return NextResponse.json({ error: 'Team A and Team B must be different' }, { status: 400 })
  }
  if (typeof body?.kickoffAt === 'string' && !isNaN(Date.parse(body.kickoffAt))) {
    data.kickoffAt = new Date(body.kickoffAt)
  }
  if (body?.durationMin != null && Number.isFinite(Number(body.durationMin))) data.durationMin = Number(body.durationMin)
  if (body?.playersPerSide != null && Number.isFinite(Number(body.playersPerSide))) data.playersPerSide = Number(body.playersPerSide)
  if (body?.goalsTarget != null && Number.isFinite(Number(body.goalsTarget))) data.goalsTarget = Number(body.goalsTarget)
  if (body?.scoreA != null && Number.isFinite(Number(body.scoreA))) data.scoreA = Number(body.scoreA)
  if (body?.scoreB != null && Number.isFinite(Number(body.scoreB))) data.scoreB = Number(body.scoreB)
  if (typeof body?.status === 'string' && ['upcoming', 'live', 'finished'].includes(body.status)) {
    data.status = body.status
  }
  if (typeof body?.venue === 'string') data.venue = body.venue.trim() || null
  if (typeof body?.notes === 'string') data.notes = body.notes.trim() || null

  const match = await db.match.update({ where: { id }, data })
  await broadcastMatchEvent({ type: 'updated', match: serialize(match) })
  return NextResponse.json({ match: serialize(match) })
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const { id } = await params
  const existing = await db.match.findUnique({ where: { id } })
  if (!existing) {
    return NextResponse.json({ error: 'Match not found' }, { status: 404 })
  }
  await db.match.delete({ where: { id } })
  await broadcastMatchEvent({ type: 'deleted', matchId: id })
  return NextResponse.json({ ok: true })
}
