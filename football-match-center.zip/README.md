# Football Match Center

A live football match organizer. The admin uploads fixtures (which team vs which team, kickoff time, score, match duration, players per side, target goals, venue, notes, status) and everyone visiting the site sees them — updated in real time when the admin makes changes.

Footer reads **"This website is made by Anish Biswas."** with Instagram (@anish25433) and WhatsApp (8240197583) buttons.

## Tech Stack
- **Framework:** Next.js 16 (App Router, TypeScript)
- **Styling:** Tailwind CSS 4 + shadcn/ui
- **Database:** PostgreSQL via Prisma ORM
- **Real-time:** socket.io (optional mini-service — see below)
- **Auth:** Cookie-based admin session with HMAC-signed tokens

## Project Structure
```
.
├── prisma/
│   └── schema.prisma          # Match model + Postgres datasource
├── public/                    # Static assets (logo, robots.txt)
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/login/    # POST — admin login
│   │   │   ├── auth/logout/   # POST — admin logout
│   │   │   ├── auth/session/  # GET — current auth state
│   │   │   ├── matches/       # GET (public) + POST (admin) matches
│   │   │   └── matches/[id]/  # PUT + DELETE (admin) a single match
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx           # The whole UI (header, hero, match board, admin panel, footer)
│   ├── components/ui/         # shadcn/ui components
│   ├── hooks/
│   └── lib/
│       ├── auth.ts            # Credential check + signed session cookies
│       ├── db.ts              # Prisma client singleton
│       ├── realtime.ts        # Helper to push live updates to socket.io
│       └── types.ts
├── mini-services/
│   └── match-realtime/        # Optional socket.io server (see Real-time section)
├── next.config.ts
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── .env.example
```

## Setup

### 1. Install dependencies
```bash
bun install    # or npm install
```

### 2. Configure environment variables
```bash
cp .env.example .env
# Edit .env and fill in real values:
#   DATABASE_URL       — a Postgres connection string (Neon, Supabase, etc.)
#   ADMIN_USERNAME     — defaults to "anish25433" if not set
#   ADMIN_PASSWORD     — defaults to "anish@25433" if not set
#   ADMIN_SESSION_SECRET — a long random string (required for production)
```

### 3. Create the database schema
```bash
bun run db:push    # or: npx prisma db push
```

### 4. Run the dev server
```bash
bun run dev    # or: npm run dev
# Open http://localhost:3000
```

### 5. (Optional) Run the real-time mini-service
For instant live updates (instead of the 20-second polling fallback):
```bash
cd mini-services/match-realtime
bun install
bun run dev    # starts socket.io on port 3003 + control endpoint on port 3004
```
The frontend automatically connects to it when available.

## Admin Login
- Username: `anish25433`
- Password: `anish@25433`

Only the admin can create, edit, and delete matches. Everyone else sees the read-only live board.

## Deploy on Vercel
1. Push the project to a Git repo (GitHub/GitLab/Bitbucket)
2. Import it into Vercel
3. Set the same environment variables in Vercel → Settings → Environment Variables
4. Deploy — Vercel auto-detects Next.js and runs `prisma generate && next build`

**Note on real-time:** Vercel is serverless and doesn't host long-running WebSocket servers. On Vercel, the site falls back to polling every 20 seconds. For instant updates, run the `mini-services/match-realtime` service on a platform that supports long-running processes (Railway, Fly.io, Render, etc.) and point the frontend to it.

## Build for production
```bash
bun run build
bun run start    # or: npm run start
```

## Scripts
- `dev` — start Next.js dev server on port 3000
- `build` — generate Prisma client + build Next.js for production
- `start` — start the production Next.js server
- `lint` — run ESLint
- `db:push` — push the Prisma schema to the database
- `db:generate` — regenerate the Prisma client

## Made by
**Anish Biswas** — [Instagram @anish25433](https://instagram.com/anish25433) · [WhatsApp 8240197583](https://wa.me/918240197583)
