import { createServer, IncomingMessage, ServerResponse } from 'http'
import { Server, Socket } from 'socket.io'

// =====================================================
// 1) Socket.io server (port 3003) — browsers connect via Caddy
//    Path MUST be '/' so Caddy can route /?XTransformPort=3003 to this port.
// =====================================================
const httpServer = createServer((req: IncomingMessage, res: ServerResponse) => {
  // Socket.io will own all requests whose URL starts with '/'.
  // Anything that doesn't match an engine.io handshake is returned to us as
  // a 404 by engine.io itself — that's expected and harmless.
  // We do NOT handle custom HTTP routes here.
  res.writeHead(404, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ error: 'This port is reserved for socket.io.' }))
})

const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

io.on('connection', (socket: Socket) => {
  console.log(`[match-realtime] client connected: ${socket.id} (total: ${io.engine.clientsCount})`)
  socket.emit('hello', { message: 'connected to match-realtime' })

  socket.on('disconnect', (reason: string) => {
    console.log(`[match-realtime] client disconnected: ${socket.id} (${reason})`)
  })
})

const IO_PORT = 3003
httpServer.listen(IO_PORT, '0.0.0.0', () => {
  console.log(`[match-realtime] socket.io server listening on port ${IO_PORT}`)
})

// =====================================================
// 2) Internal control HTTP server (port 3004) — localhost only.
//    Used by the Next.js API routes to push live updates to browsers.
// =====================================================
const controlServer = createServer((req: IncomingMessage, res: ServerResponse) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }

  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ ok: true, clients: io.engine.clientsCount }))
    return
  }

  if (req.method === 'POST' && req.url === '/internal/broadcast') {
    const remote = req.socket.remoteAddress || ''
    const isLocal = remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1'
    if (!isLocal) {
      res.writeHead(403, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ error: 'Forbidden' }))
      return
    }
    let raw = ''
    req.on('data', (chunk) => { raw += chunk })
    req.on('end', () => {
      try {
        const payload = JSON.parse(raw)
        io.emit('match:event', payload)
        res.writeHead(200, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ ok: true, listeners: io.engine.clientsCount }))
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ error: 'Invalid JSON' }))
      }
    })
    return
  }

  res.writeHead(404, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ error: 'Not found' }))
})

const CONTROL_PORT = 3004
controlServer.listen(CONTROL_PORT, '127.0.0.1', () => {
  console.log(`[match-realtime] internal control server listening on port ${CONTROL_PORT} (localhost only)`)
})

process.on('SIGTERM', () => {
  console.log('[match-realtime] SIGTERM, shutting down...')
  io.close()
  httpServer.close(() => controlServer.close(() => process.exit(0)))
})
process.on('SIGINT', () => {
  console.log('[match-realtime] SIGINT, shutting down...')
  io.close()
  httpServer.close(() => controlServer.close(() => process.exit(0)))
})
